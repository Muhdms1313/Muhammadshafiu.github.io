MUHD_MS PERSONAL PORTFOLIO
============================

Files:
- index.html  -> main website
- style.css   -> responsive design and animations
- script.js   -> mobile menu, scroll reveal, active navigation, back-to-top

HOW TO USE:
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Firefox.
3. To publish online, upload the three files to a static hosting service.

CUSTOMIZE:
- Replace the "MS" avatar with your own photo later if desired.
- Update email/social links in index.html.
- Update skills and project descriptions as your work grows.

The design is responsive for phones, tablets and computers.
